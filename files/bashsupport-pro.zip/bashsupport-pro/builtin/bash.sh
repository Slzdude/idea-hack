declare CDPATH

declare MAILCHECK

declare MAILPATH

declare TERM

declare auto_resume

declare BASH

declare BASHOPTS

declare BASHPID

declare BASH_ALIASES

declare BASH_ARGC

declare BASH_ARGV

declare BASH_ARGV0

declare BASH_CMDS

declare BASH_COMMAND

declare BASH_COMPAT

declare BASH_ENV

declare BASH_EXECUTION_STRING

declare BASH_LINENO

declare BASH_LOADABLES_PATH

declare BASH_REMATCH

declare BASH_SOURCE

declare BASH_SUBSHELL

declare BASH_VERSINFO

declare BASH_VERSION

declare BASH_XTRACEFD

declare CHILD_MAX

declare COLUMNS

declare COMP_CWORD

declare COMP_LINE

declare COMP_POINT

declare COMP_TYPE

declare COMP_KEY

declare COMP_WORDBREAKS

declare COMP_WORDS

declare COMPREPLY

declare COPROC

declare DIRSTACK

declare EMACS

declare EPOCHREALTIME

declare EPOCHSECONDS

declare -r EUID

declare EXECIGNORE

declare FCEDIT

declare FIGNORE

declare FUNCNAME

declare FUNCNEST

declare GLOBIGNORE

declare GROUPS

declare histchars

declare HISTCMD

declare HISTCONTROL

declare HISTFILE

declare HISTFILESIZE

declare HISTIGNORE

declare HISTSIZE

declare HISTTIMEFORMAT

declare HOSTFILE

declare HOSTNAME

declare HOSTTYPE

declare IGNOREEOF

declare INPUTRC

declare INSIDE_EMACS

declare LINES

declare MACHTYPE

declare MAPFILE

declare OLDPWD

declare OPTERR

declare OSTYPE

declare PIPESTATUS

declare POSIXLY_CORRECT

declare PROMPT_COMMAND

declare PROMPT_DIRTRIM

declare PS0

declare PS3

declare RANDOM

declare READLINE_LINE

declare READLINE_POINT

declare REPLY

declare SECONDS

declare SHELL

declare SHELLOPTS

declare SHLVL

declare TIMEFORMAT

declare TMOUT

declare TMPDIR

declare -r UID