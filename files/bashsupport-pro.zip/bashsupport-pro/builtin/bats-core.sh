# The fully expanded path to the Bats test file.
declare BATS_TEST_FILENAME

# The directory in which the Bats test file is located.
declare BATS_TEST_DIRNAME

# An array of function names for each test case.
declare -a BATS_TEST_NAMES

# The name of the function containing the current test case.
declare BATS_TEST_NAME

# The description of the current test case.
declare BATS_TEST_DESCRIPTION

# The (1-based) index of the current test case in the test file.
declare BATS_TEST_NUMBER

# The location to a directory that may be used to store temporary files.
declare -x BATS_TMPDIR