typeset -A _Dbg_cmdloop_hooks
