Copyright © 2003, 2006–2007, 2016 Rocky Bernstein
GNU GENERAL PUBLIC LICENSE

bashdb is a wonderful piece of software. It provides the foundation for the debugger integration.
Please see LICENSE.txt for the full text of the GPLv2.

BashSupport Pro bundles versions 4.4 and 5.0 of bashdb.
These versions are slightly modified to improve interoperability with BashSupport Pro.
Most of the changes were already submitted to the SourceForge project page.
All changes are available online:
    bashdb 5.0: https://github.com/BashSupport-Pro/bashdb/tree/bashsupport-5.0
    bashdb 4.4: https://github.com/BashSupport-Pro/bashdb/tree/bashsupport-4.4

You can find the license at /license/bashdb_license.txt in the distributed zip file.
You can find the sources at /sources/ in the distributed zip file.