This is BashSupport Pro.
Website: https://www.bashsupport.com/

Licenses of used software components are available in ./licenses.
Sources of used software components are available in ./sources.
shfmt binaries are compressed with "upx --best".

Online git repositories of the same sources:
- https://github.com/BashSupport-Pro/shellcheck
- https://github.com/BashSupport-Pro/bashdb